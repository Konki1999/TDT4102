#pragma once

int randomWithLimits(int lower, int upper);