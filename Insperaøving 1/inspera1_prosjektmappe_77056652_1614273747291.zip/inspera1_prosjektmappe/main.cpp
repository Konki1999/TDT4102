#include "std_lib_facilities.h"

int main()
{
	cout << "Hello TDT4102 insperaøving 1!\n";

	keep_window_open();
}
