#include "survey2021.h"

// Implement all the necessary functions as described in the task.
