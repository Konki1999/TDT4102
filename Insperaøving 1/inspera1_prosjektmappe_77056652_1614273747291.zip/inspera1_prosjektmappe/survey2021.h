#include "std_lib_facilities.h"

//Declare relevant functions for the task. 