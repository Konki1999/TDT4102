#pragma once
#include "std_lib_facilities.h"

// Task a)
// Create an color enum here


// Task b) 
// Complete the Vehicle class as described in the task
class Vehicle {};


// Task c)
// Create the Car class underneath as described in the task
