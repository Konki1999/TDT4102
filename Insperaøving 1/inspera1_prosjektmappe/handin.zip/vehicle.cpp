#include "vehicle.h"

// Implement all the necessary functions as described in the task here.

