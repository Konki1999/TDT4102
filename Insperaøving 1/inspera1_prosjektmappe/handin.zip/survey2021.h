#pragma once
#include "std_lib_facilities.h"
#include <iostream>
#include <fstream>

//Declare relevant functions for the task. 

map<string,int> mapSurvey();
vector<string> sortVector(map<string,int> map);
void surveyResults(map<string,int> map);