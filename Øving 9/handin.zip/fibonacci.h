#pragma once
#include <iostream>
#include <vector>
#include <map>
#include <string>

using namespace std;

void fillInFibonacciNumbers(int result[], int length);
void printArray(int arr[], int length);
void createFibonacci();