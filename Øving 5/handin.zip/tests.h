#pragma once
#include "CardDeck.h"

void testCard();
void testCardDeck();