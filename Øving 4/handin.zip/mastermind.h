#pragma once
#include "std_lib_facilities.h"
#include "masterVisual.h"

void playMastermind();
void playMastermindVisual();
int checkCharactersAndPosition(string code, string guess);
int checkCharacters(string code, string guess);