#pragma once

#include "std_lib_facilities.h"

void testCallByValue();
void testCallByReference();
void testSwap();
void testToLower();
void testStudent();
void testString();
void testReadToString();
void testCountChar();