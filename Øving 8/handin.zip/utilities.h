#pragma once
#include "std_lib_facilities.h"

bool alphastr(string str);